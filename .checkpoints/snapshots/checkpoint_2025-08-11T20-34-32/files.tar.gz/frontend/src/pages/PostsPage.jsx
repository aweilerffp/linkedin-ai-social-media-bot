function PostsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Posts</h1>
      <p>Post management coming soon...</p>
    </div>
  );
}

export default PostsPage;