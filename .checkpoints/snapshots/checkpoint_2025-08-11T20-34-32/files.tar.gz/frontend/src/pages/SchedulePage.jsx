function SchedulePage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Schedule</h1>
      <p>Post scheduling coming soon...</p>
    </div>
  );
}

export default SchedulePage;